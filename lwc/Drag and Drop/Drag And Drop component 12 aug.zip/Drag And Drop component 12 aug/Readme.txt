*Please add ModalWidthCSS file in static Resources with same name
*Make a lightning quick action button on opportunity layout, add Aura component there and give label as you desire.