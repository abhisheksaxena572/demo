declare module "@salesforce/apex/productData.allProd" {
  export default function allProd(): Promise<any>;
}
declare module "@salesforce/apex/productData.subList" {
  export default function subList(): Promise<any>;
}
declare module "@salesforce/apex/productData.serviceList" {
  export default function serviceList(): Promise<any>;
}
declare module "@salesforce/apex/productData.inventList" {
  export default function inventList(): Promise<any>;
}
declare module "@salesforce/apex/productData.oli" {
  export default function oli(param: {arr: any, recordId: any}): Promise<any>;
}
