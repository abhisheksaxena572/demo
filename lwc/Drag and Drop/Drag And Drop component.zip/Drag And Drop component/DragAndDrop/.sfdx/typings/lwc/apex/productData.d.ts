declare module "@salesforce/apex/productData.subList" {
  export default function subList(): Promise<any>;
}
declare module "@salesforce/apex/productData.serviceList" {
  export default function serviceList(): Promise<any>;
}
declare module "@salesforce/apex/productData.inventList" {
  export default function inventList(): Promise<any>;
}
declare module "@salesforce/apex/productData.oneYear" {
  export default function oneYear(param: {prodName: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/productData.twoYear" {
  export default function twoYear(param: {prodName: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/productData.threeYear" {
  export default function threeYear(param: {prodName: any, recordId: any}): Promise<any>;
}
