declare module "@salesforce/apex/filesChatterGroup.getFiles" {
  export default function getFiles(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/filesChatterGroup.filterResult" {
  export default function filterResult(param: {filterVal: any}): Promise<any>;
}
